/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example.cw;

import core.State;
import core.Task;
import domain.cw.CWTask;
import static example.cw.TestNPPGPolicy.maxStep;
import experiment.Experiment;
import java.util.Random;
import policy.DemonRankBoostPoolPolicy;
import policy.NPPGPolicy;
import policy.RankBoostPoolPolicy;
import policy.RankBoostPoolWithoutEXPPolicy;
import utills.IO;

/**
 *
 * @author daq
 */
public class TestPolicy {

    static int maxStep = 200;
    static boolean isPara = true;

    public static void run(int trial) throws Exception {
        Random random = new Random();
        Task task = new CWTask(new Random(random.nextInt()));
        State initialState = task.getInitialState();

        Experiment exp = null;

//        NPPGPolicy gbPolicy = new NPPGPolicy(new Random(random.nextInt()));
//        gbPolicy.setStationaryRate(0.5);
//        gbPolicy.setStepsize(0.05);
//        gbPolicy.setEpsionGreedy(0.1);
//        gbPolicy.setStationaryRate(0.5);
//        gbPolicy.setStepsize(1);
//        gbPolicy.setEpsionGreedy(0);
//        gbPolicy.setEpsionGreedyDecay(1);
//        gbPolicy.setMaxStep(maxStep);
//        exp = new Experiment();
//        double[][] resultsNPPG = exp.conductExperimentTrain(gbPolicy, task, 100, 30, initialState, maxStep, true, 0, new Random(random.nextInt()));
//        IO.matrixWrite(resultsNPPG, "results/cw/NPPG/trial_" + trial + ".txt");
        int demoNum = 2;
        for(demoNum = 2; demoNum <= 10; demoNum += 2) {
            RankBoostPoolPolicy bp = new RankBoostPoolPolicy(new Random(random.nextInt()), 0, demoNum);
            bp.setStepsize(1);
            exp = new Experiment();
            double[][] resultsPB = exp.conductExperimentTrain(bp, task, 50, 30, initialState, maxStep, isPara, 0.2, new Random(random.nextInt()));
            IO.matrixWrite(resultsPB, "results/cw/DPB(v111)/PB_demo" + demoNum + "_trial" + trial + ".txt");
        }
        
        double thre = 0.6;
        double alpha = 1;
        demoNum = 2;
        for(demoNum = 2; demoNum <= 10; demoNum += 2) {
            //System.out.println("haha");
            DemonRankBoostPoolPolicy bp1 = new DemonRankBoostPoolPolicy(new Random(random.nextInt()), thre, alpha, 0, demoNum);
            bp1.setStepsize(1);
            exp = new Experiment();
            double[][] resultsDPB = exp.conductExperimentTrain(bp1, task, 50, 30, initialState, maxStep, isPara, 0.2, new Random(random.nextInt()));
            IO.matrixWrite(resultsDPB, "results/cw/DPB(v311)/DPB_demo" + demoNum + "_trial" + trial + ".txt");
        }
        


        
    }
}
