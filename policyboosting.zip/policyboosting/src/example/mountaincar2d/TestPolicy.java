/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example.mountaincar2d;

import example.cw.*;
import core.State;
import core.Task;
import domain.cw.CWTask;
import domain.mountaincar2d.MountainCarTask;
import experiment.Experiment;
import java.util.Random;
import policy.DemonRankBoostPoolPolicy;
import policy.NPPGPolicy;
import policy.RankBoostPoolPolicy;
import policy.RankBoostPoolWithoutEXPPolicy;
import utills.IO;

/**
 *
 * @author daq
 */
public class TestPolicy {

    static int maxStep = 2000;
    static boolean isPara = true;

    public static void run(int trial) throws Exception {
        Random random = new Random();
        Task task = new MountainCarTask(new Random(random.nextInt()));
        State initialState = task.getInitialState();

        Experiment exp = null;

//        NPPGPolicy gbPolicy = new NPPGPolicy(new Random(random.nextInt()));
//        gbPolicy.setStationaryRate(0.7);
//        gbPolicy.setStepsize(0.1);
//        gbPolicy.setEpsionGreedy(0.2);
//        gbPolicy.setStationaryRate(0.7);
//        gbPolicy.setStepsize(1);
//        gbPolicy.setEpsionGreedy(0);
//        gbPolicy.setMaxStep(maxStep);
//        exp = new Experiment();
//        double[][] resultsNPPG = exp.conductExperimentTrain(gbPolicy, task, 100, 50, initialState, maxStep, true, 0, new Random(random.nextInt()));
//        IO.matrixWrite(resultsNPPG, "results/mc/NPPG/trial_" + trial + ".txt");
        
        
//        RankBoostPoolPolicy bp = new RankBoostPoolPolicy(new Random(random.nextInt()));
//        bp.setStepsize(1);
//        exp = new Experiment();
//        double[][] resultsPB = exp.conductExperimentTrain(bp, task, 100, 50, initialState, maxStep, isPara, 0, new Random(random.nextInt()));
//
//        RankBoostPoolWithoutEXPPolicy pbNoExp = new RankBoostPoolWithoutEXPPolicy(new Random(random.nextInt()));
//        pbNoExp.setStepsize(1);
//        exp = new Experiment();
//        double[][] resultsPBNoExp = exp.conductExperimentTrain(pbNoExp, task, 100, 50, initialState, maxStep, isPara, 0, new Random(random.nextInt()));

//        IO.matrixWrite(resultsNPPG, "results/mc/NPPGF_trial_" + trial + ".txt");
//        IO.matrixWrite(resultsPB, "results/mc/PB_trial_" + trial + ".txt");
        //IO.matrixWrite(resultsPBNoExp, "results/mc/PBNoPool_trial_" + trial + ".txt");
        
        int demoNum = 2;
        for(demoNum = 2; demoNum <= 10; demoNum += 2) {
            RankBoostPoolPolicy bp = new RankBoostPoolPolicy(new Random(random.nextInt()), 1, demoNum);
            bp.setStepsize(1);
            exp = new Experiment();
            double[][] resultsPB = exp.conductExperimentTrain(bp, task, 50, 50, initialState, maxStep, isPara, 0.2, new Random(random.nextInt()));
            IO.matrixWrite(resultsPB, "results/mc/DPB(v1111)/PB_demo" + demoNum + "_trial" + trial + ".txt");
        }
         
         
         double thre = 0.6;
         double alpha = 1;
         for(demoNum = 2; demoNum <= 10; demoNum += 2) {
            DemonRankBoostPoolPolicy bp1 = new DemonRankBoostPoolPolicy(new Random(random.nextInt()), thre, alpha, 1, demoNum);
            bp1.setStepsize(1);
            exp = new Experiment();
            double[][] resultsDPB = exp.conductExperimentTrain(bp1, task, 50, 50, initialState, maxStep, isPara, 0.2, new Random(random.nextInt()));
            IO.matrixWrite(resultsDPB, "results/mc/DPB(v3111)/DPB_demo" + demoNum + "_trial" + trial + ".txt");
         }
    }
}
