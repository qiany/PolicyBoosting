/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example.helicopter;

import core.State;
import core.Task;
import domain.helicopter.HelicopterTask;
import experiment.Experiment;
import java.util.Random;
import policy.DemonRankBoostPoolCANappingPolicy;
import policy.RankBoostPoolCANappingPolicy;
import utills.IO;

/**
 * example.helicopter.TestRankBoostPoolCAPolicy
 *

 */
public class TestDemonRankBoostPoolCAPolicy {

    static int maxStep = 8000;
    static boolean isPara = true;

    public static void run(int trial) throws Exception {
        

        Random random = new Random();
        Task task = new HelicopterTask(new Random(random.nextInt()));
        State initialState = task.getInitialState();

        Experiment exp = new Experiment();
        
        double thre = 1;
        double alpha = 1;
        int demoNum;
        for(demoNum = 10; demoNum <= 10; demoNum += 10) {
            
            
            DemonRankBoostPoolCANappingPolicy bpca = new DemonRankBoostPoolCANappingPolicy(new Random(random.nextInt()), 100, thre, alpha);
            bpca.setStepsize(1);
            exp = new Experiment();
            double[][] resultsDPB = exp.conductExperimentTrainCA(bpca, task, 1000, 100, initialState, maxStep, isPara, new Random(random.nextInt()), false);
            IO.matrixWrite(resultsDPB, "results/helicopter/DPB(v2)/DPB_demo" + demoNum + "_trial" + trial + ".txt");
        
        }
        
       
    }
}
