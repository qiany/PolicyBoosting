/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example.helicopter;

import core.State;
import core.Task;
import domain.helicopter.HelicopterTask;
import experiment.Experiment;
import java.util.Random;
import policy.RankBoostPoolCANappingPolicy;
import utills.IO;

/**
 * example.helicopter.TestRankBoostPoolCAPolicy
 *
 * @author daq
 */
public class TestRankBoostPoolCAPolicy {

    static int maxStep = 10000;
    static boolean isPara = true;

    public static void run(int trial) throws Exception {
        

        Random random = new Random();
        Task task = new HelicopterTask(new Random(random.nextInt()));
        State initialState = task.getInitialState();

        Experiment exp = new Experiment();

//        RankBoostPoolCAPolicy bpca = new RankBoostPoolCAPolicy(new Random(random.nextInt()));
        RankBoostPoolCANappingPolicy bpca = new RankBoostPoolCANappingPolicy(new Random(random.nextInt()), 100);
        bpca.setStepsize(1);

        double[][] resultys = exp.conductExperimentTrainCA(bpca, task, 800, 100, initialState, maxStep, isPara, new Random(random.nextInt()), true);
        IO.matrixWrite(resultys, "results/helicopter/PBWP_trial_" + trial + ".txt");
    }
}
