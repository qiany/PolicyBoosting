/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example.helicopter;

import core.State;
import core.Task;
import domain.helicopter.HelicopterTask;
import static example.helicopter.TestRankBoostPoolCAPolicy.maxStep;
import experiment.Experiment;
import java.util.Random;
import policy.NPPGCAPolicy;
import policy.RankBoostPoolCANappingPolicy;
import utills.IO;

/**
 *
 * @author daq
 */
public class TestNPPGCAPolicy {

    static int maxStep = 8000;
    static boolean isPara = true;

    public static void main(String[] args) throws Exception {
//        args = new String[]{"0", "0"};
        for (int trial = Integer.parseInt(args[0]); trial <= Integer.parseInt(args[1]); trial++) {

            Random random = new Random();
            Task task = new HelicopterTask(new Random(random.nextInt()));
            State initialState = task.getInitialState();

            Experiment exp = new Experiment();

            NPPGCAPolicy nppg = new NPPGCAPolicy(new Random(random.nextInt()));
            nppg.setStepsize(0.5);
            nppg.setStationaryRate(1);
            nppg.setMaxStep(maxStep);
            double[][] resultys = exp.conductExperimentTrainCA(nppg, task, 1000, 50, initialState, maxStep, isPara, new Random(random.nextInt()), false);
            IO.matrixWrite(resultys, "results/heli/NPPG_trial_" + trial + ".txt");
        }
    }
}
