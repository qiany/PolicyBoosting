/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package experiment;

import core.*;
import domain.helicopter.HelicopterState;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import policy.RankBoostPoolCANappingPolicy;
import policy.RankBoostPoolPolicy;
import utills.Stats;

/**
 *
 * @author daq
 */
public class Experiment {

    class ParallelExecute implements Runnable {

        private Trajectory rollout;
        private Task task;
        private Policy policy;
        private State initialState;
        private int maxStep;
        private Random random;
        boolean isStochastic;

        public ParallelExecute(Task task, Policy policy, State initialState,
                int maxStep, boolean isStochastic, int seed) {
            this.task = task;
            this.policy = policy;
            this.initialState = initialState;
            this.maxStep = maxStep;
            this.isStochastic = isStochastic;
            this.random = new Random(seed);
        }

        public void run() {
            rollout = Execution.runTaskWithFixedStep(task,
                    initialState, policy, maxStep, isStochastic, random);
        }

        public Trajectory getRollout() {
            return rollout;
        }
    }

    public double[][] conductExperimentTrain(Policy policy, Task task,
            int iteration, int trialsPerIter, State initialState, int maxStep,
            boolean isPara, double epsion, Random random) {
        double[][] results = new double[iteration][6];
        List<Trajectory> rolloutsFirst = null;
        for (int iter = 0; iter < iteration; iter++) {
            results[iter][0] = iter;
            System.out.print("iter=" + iter + ", ");

            Policy explorePolicy = new EpsionGreedyExplorePolicy(policy, epsion, new Random(random.nextInt()));
            List<ParallelExecute> list = new ArrayList<ParallelExecute>();

            ExecutorService exec = Executors.newFixedThreadPool(
                    Runtime.getRuntime().availableProcessors() - 1);
            for (int i = 0; i < trialsPerIter; i++) {
                ParallelExecute run = new ParallelExecute(task, explorePolicy,
                        initialState, maxStep, true, random.nextInt());
                list.add(run);
                if (isPara && iter > 0) {
                    exec.execute(run);
                } else {
                    run.run();
                }
            }
            if (isPara && iter > 0) {
                exec.shutdown();
                try {
                    while (!exec.awaitTermination(10, TimeUnit.SECONDS)) {
                    }
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }

            List<Trajectory> rollouts = new ArrayList<Trajectory>();
            double[] rewards = new double[list.size()];
            double[] steps = new double[list.size()];
            int cc = 0;
            for (ParallelExecute run : list) {
                Trajectory rollout = run.getRollout();
                rollout.setProducedIteration(iter);
                rollouts.add(rollout);

                double totalReward = rollout.getRewards();
                rewards[cc] = totalReward;
                steps[cc] = rollout.getSamples().size();
                cc++;
                
            }
            double[] meanStdReward = Stats.mean_std(rewards);
            double[] meanStdStep = Stats.mean_std(steps);
            results[iter][1] = meanStdReward[0];
            results[iter][2] = meanStdReward[1];
            results[iter][3] = meanStdStep[0];
            results[iter][4] = meanStdStep[1];
            System.out.println("Average Total Rewards = " + meanStdReward[0] + ", Average step = " + meanStdStep[0]);

//            if (iter == 0) {
//                rolloutsFirst = rollouts;
//            } else {
//                rollouts = rolloutsFirst;
//            }

            //policy.update(rollouts, iter);
            policy.update(rollouts);
            
            results[iter][5] = ((GibbsPolicy)policy).normalizedWeightedRewards;
            
            // collect optimal demonstration
//            if(iter == iteration - 1) {
//                Trajectory[] tra = ((RankBoostPoolPolicy)policy).getBestTrajectory();
//                System.out.println("*************" + tra.length);
//                for(int i = 0; i < tra.length; i++) {
//                    Trajectory t = tra[i];
//                    BufferedWriter w = new BufferedWriter(new FileWriter("results//cw//demonstration//" + i + ".txt"));
//                    w.write(t.getRewards() + "\n");
//                    w.flush();
//                    List<Tuple> samples = t.getSamples();
//                    for(int j = 0; j < samples.size(); j++) {
//                        Tuple sample = samples.get(j);
//                        double[] f = sample.s.getfeatures();
//                        for(int k = 0; k < f.length; k++) {
//                            if(k == f.length - 1) {
//                                w.write(f[k] + "\t");
//                                w.flush();
//                            } else {
//                                w.write(f[k] + " ");
//                                w.flush();
//                            }
//                        }
//                        w.write(sample.action.a + " " + ((PrabAction) sample.action).probability + "\t");
//                        w.flush();
//                        f = sample.sPrime.getfeatures();
//                        for(int k = 0; k < f.length; k++) {
//                            if(k == f.length - 1) {
//                                w.write(f[k] + "\t");
//                                w.flush();
//                            } else {
//                                w.write(f[k] + " ");
//                                w.flush();
//                            }
//                        }
//                        w.write(sample.reward + "\n");
//                        w.flush();
//                         
//                    }
//                    
//                }
//                        
//            }
//            ParallelExecute run = new ParallelExecute(task, policy,
//                    initialState, maxStep, true, random.nextInt());
//            run.run();
//            Trajectory rollout = run.getRollout();
//            System.err.println("DDDD " + rollout.getRewards());
        }

        return results;
    }

    public double[][] conductExperimentTrainCA(Policy policy, Task task,
            int iteration, int trialsPerIter, State initialState, int maxStep,
            boolean isPara, Random random, boolean write) throws Exception{
        double[][] results = new double[iteration][5];
        List<Trajectory> rolloutsFirst = null;
        for (int iter = 0; iter < iteration; iter++) {
            System.out.print("iter=" + iter + ", ");
            //  System.out.println("collecting samples...");

            Policy explorePolicy = new ExploreCAPolicy(policy, 0.0, new Random(random.nextInt()));
            List<ParallelExecute> list = new ArrayList<ParallelExecute>();

            ExecutorService exec = Executors.newFixedThreadPool(
                    Runtime.getRuntime().availableProcessors() - 1);
            for (int i = 0; i < (iter == 0 ? 1000 : trialsPerIter); i++) {
                ParallelExecute run = new ParallelExecute(task, explorePolicy,
                        initialState, maxStep, i == 0 ? false : true, random.nextInt());
                list.add(run);
                if (isPara && iter > 0) {
                    exec.execute(run);
                } else {
                    run.run();
                }
            }
            if (isPara && iter > 0) {
                exec.shutdown();
                try {
                    while (!exec.awaitTermination(10, TimeUnit.SECONDS)) {
                    }
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }

            List<Trajectory> rollouts = new ArrayList<Trajectory>();
            double[] rewards = new double[list.size()];
            double[] steps = new double[list.size()];
            int cc = 0, maxStepUsed = -1;
            for (ParallelExecute run : list) {
                Trajectory rollout = run.getRollout();
                rollout.setProducedIteration(iter);
                rollouts.add(rollout);

                double totalReward = rollout.getRewards();
                rewards[cc] = totalReward;
                steps[cc] = rollout.getSamples().size();

                if (steps[cc] > maxStepUsed) {
                    maxStepUsed = rollout.getSamples().size();
                }

                cc++;
            }
            double[] meanStdReward = Stats.mean_std(rewards);
            double[] meanStdStep = Stats.mean_std(steps);
            results[iter][1] = meanStdReward[0];
            results[iter][2] = meanStdReward[1];
            results[iter][3] = meanStdStep[0];
            results[iter][4] = meanStdStep[1];
            System.out.println("Average Total Rewards = " + meanStdReward[0] + ", Average step = " + meanStdStep[0] + "(" + maxStepUsed + ")");

//            if(meanStdStep[0] > 6500)
//                break;
            // System.out.println();
            // System.out.println("collecting samples is done! Updating meta-policy...");

//            if (iter == 0) {
//                rolloutsFirst = rollouts;
//            } else {
//                rollouts = rolloutsFirst;
//            }

            //policy.update(rollouts, iter);
            //System.out.println("haha");
            policy.update(rollouts);
            // collect optimal demonstration
            if(iter == iteration - 1 && write == true) {
                Trajectory[] tra = ((RankBoostPoolCANappingPolicy)policy).getBestTrajectory();
                System.out.println("*************" + tra.length);
                for(int i = 0; i < tra.length; i++) {
                    Trajectory t = tra[i];
                    BufferedWriter w = new BufferedWriter(new FileWriter("results//helicopter//demonstration//" + i + ".txt"));
                    w.write(t.getRewards() + "\n");
                    w.flush();
                    List<Tuple> samples = t.getSamples();
                    for(int j = 0; j < samples.size(); j++) {
                        Tuple sample = samples.get(j);
                        HelicopterState hs = (HelicopterState)sample.s;
                        w.write(hs.getEnvTerminal() + " ");
                        w.write(hs.getSimSteps() + " ");
                        w.write(hs.getVelocity() + " ");
                        w.write(hs.getPosition() + " ");
                        w.write(hs.getAngular() + " ");
                        w.write(hs.getQ() + " ");
                        w.write(hs.getNoise() + "\t");
                        
                        w.write(((PrabAction) sample.action).probability + " ");
                        w.flush();
                        for(int m = 0; m < sample.action.controls.length; m++) {
                            if(m == sample.action.controls.length - 1) {
                                w.write(sample.action.controls[m] + "\t");
                                w.flush();
                            } else {
                                w.write(sample.action.controls[m] + " ");
                                w.flush();
                            }
                        }
                        
                        HelicopterState hsP = (HelicopterState)sample.s;
                        w.write(hsP.getEnvTerminal() + " ");
                        w.write(hsP.getSimSteps() + " ");
                        w.write(hsP.getVelocity() + " ");
                        w.write(hsP.getPosition() + " ");
                        w.write(hsP.getAngular() + " ");
                        w.write(hsP.getQ() + " ");
                        w.write(hsP.getNoise() + "\t");
                       
                        w.write(sample.reward + "\n");
                        w.flush();
                         
                    }
                    
                }
                        
            }
            //policy.update(rollouts);
//            ParallelExecute run = new ParallelExecute(task, policy,
//                    initialState, maxStep, true, random.nextInt());
//            run.run();
//            Trajectory rollout = run.getRollout();
//            System.err.println("DDDD " + rollout.getRewards());         
        }

        return results;
    }

    public static double[] calcRolloutObjective(Trajectory rollout, GibbsPolicy policy) {
        double[] obj = new double[3];

        double log_P_pi_z = 0;

        double R_pi_z = 0;
        for (Tuple sample : rollout.getSamples()) {
            double[] probability = policy.getProbability(sample.s, rollout.getTask());
            R_pi_z += sample.reward * probability[sample.action.a];
            log_P_pi_z += Math.log(probability[sample.action.a]);
        }
        obj[0] = Math.exp(log_P_pi_z);
        obj[1] = R_pi_z;
        obj[2] = obj[0] * R_pi_z;

        return obj;
    }

    public static double[] calcObjective(List<Trajectory> rollouts, GibbsPolicy policy) {
        double[] objective = new double[3];

        for (Trajectory rollout : rollouts) {
            double[] obj = calcRolloutObjective(rollout, policy);
            for (int i = 0; i < obj.length; i++) {
                System.err.print(obj[i] + ",");
                objective[i] += obj[i];
            }
            System.err.println();
        }

        return objective;
    }
}
