/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package auto;

import core.State;
import core.Task;
import domain.mountaincar2d.MountainCarTask;
import experiment.Experiment;
import java.util.Random;
import policy.NPPGPolicy;
import policy.RankBoostPoolPolicy;
import utills.IO;

/**
 *
 * @author daq
 */
public class TestNormalizedWeightedRewards {

    static int maxStep = 2000;
    static boolean isPara = true;

    public static void main(String[] args) throws Exception {
        for (int trial = 0; trial <= 0; trial++) {

            Random random = new Random();
            Task task = new MountainCarTask(new Random(random.nextInt()));
            State initialState = task.getInitialState();

            Experiment exp = null;

//            NPPGPolicy gbPolicy = new NPPGPolicy(new Random(random.nextInt()));
//            gbPolicy.setStationaryRate(0.7);
//            gbPolicy.setStepsize(0.1);
//            gbPolicy.setEpsionGreedy(0.2);
//            gbPolicy.setMaxStep(maxStep);
//            exp = new Experiment();
//            double[][] resultsNPPG = exp.conductExperimentTrain(gbPolicy, task, 100, 50, initialState, maxStep, true, 0, new Random(random.nextInt()));
//            IO.matrixWrite(resultsNPPG, "results/nwr/mc/NPPGF_trial_" + trial + ".txt");

            RankBoostPoolPolicy bp = new RankBoostPoolPolicy(new Random(random.nextInt()), 1);
            bp.setStepsize(1);
            exp = new Experiment();
            double[][] resultsPB = exp.conductExperimentTrain(bp, task, 100, 50, initialState, maxStep, isPara, 0, new Random(random.nextInt()));
            IO.matrixWrite(resultsPB, "results/PB_trial_" + trial + ".txt");
        }
    }
}
