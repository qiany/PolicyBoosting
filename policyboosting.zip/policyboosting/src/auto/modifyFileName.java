/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package auto;
import java.io.File;
import java.io.IOException;
/**
 *
 * @author Qian Yu
 */
public class modifyFileName {



 public static void main(String[] args) throws IOException 
 {
 
//                String rootPath = "results/helicopter/DPB";
//		File filed=new File(rootPath);
//		File[] FS=filed.listFiles();
//		for(int index=0;index<FS.length;index++)
//		{
//                    String s = FS[index].getName();
//                    String[] com = s.split("_");
//                    Double num = Math.abs(Double.parseDouble(com[2]));
//                    String localPath = com[0] + "_" + com[1] + "_" + num + "_" + com[3] + "_" + com[4] + "_" + com[5] + "_" + com[6];
//                    System.out.println(rootPath + "/" + localPath);
//                
//                    FS[index].renameTo(new File(rootPath + "/" + localPath));
//		}
                
                
                String rootPath = "results/mc/DPB(para)";
		File filed=new File(rootPath);
		File[] FS=filed.listFiles();
		for(int index=0;index<FS.length;index++)
		{
                    String s = FS[index].getName();
                    String[] com = s.split("_");
                    Double num = Math.abs(Double.parseDouble(com[2]));
                    String localPath;
                    if(Math.abs(num - 0.8) < 0.01)                        
                        localPath = com[0] + "_" + com[1] + "_" + "0.8" + "_" + com[3] + "_" + com[4] + "_" + com[5] + "_" + com[6];
                    else
                        localPath = com[0] + "_" + com[1] + "_" + num + "_" + com[3] + "_" + com[4] + "_" + com[5] + "_" + com[6];
                    //System.out.println(rootPath + "/" + localPath);
                
                    FS[index].renameTo(new File(rootPath + "/" + localPath));
		}
                
 }
	

    
}
