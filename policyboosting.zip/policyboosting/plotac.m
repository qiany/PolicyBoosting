clear;
clear;
count = 1;
for i = 0:99
    load(['results\acrobot\PB\PB_trial_',num2str(i),'.txt']);
    s = ['stepPB(:,count) = PB_trial_',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepPBMean = mean(stepPB, 2);


i = 1;
load(['results\acrobot\Sarsa\result',num2str(i),'.mat']);
s = ['stepSarsa = result'];
eval(s);
stepSarsaMean = mean(stepSarsa, 1);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v11)\PB_demo8_trial',num2str(i),'.txt']);
    s = ['stepDPBV1(:,count) = PB_demo8_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV1Mean = mean(stepDPBV1, 2);


count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo10_trial',num2str(i),'.txt']);
    s = ['stepDPBV2(:,count) = DPB_demo10_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV2Mean = mean(stepDPBV2, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v31)\DPB_demo8_trial',num2str(i),'.txt']);
    s = ['stepDPBV3(:,count) = DPB_demo8_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV3Mean = mean(stepDPBV3, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\NPPG\NPPG_trial_',num2str(i),'.txt']);
    s = ['stepNPPG(:,count) = NPPG_trial_',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepNPPGMean = mean(stepNPPG, 2);

x = 1:1:50;
semilogx(x,stepNPPGMean(1:50),'p');
hold on;
semilogx(x,stepSarsaMean(1:50),'g');
hold on;
semilogx(x,stepPBMean(1:50),'r');
hold on;
semilogx(x,stepDPBV1Mean(1:50),'b');
hold on;
semilogx(x,stepDPBV2Mean,'k');
hold on;
semilogx(x,stepDPBV3Mean(1:50),'y');

legend('NPPG', 'Sarsa','PB', 'DPBV1','DPBV2','DPBV3');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(new demo)\DPB_r_0.6_alpha_0.1_trial_',num2str(i),'.txt']);
%     s = ['stepV1(:,count) = DPB_r_0_6_alpha_0_1_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV1Mean = mean(stepV1, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(new demo)\DPB_r_0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepV2(:,count) = DPB_r_0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV2Mean = mean(stepV2, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(new demo)\DPB_r_0.6_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepV3(:,count) = DPB_r_0_6_alpha_10_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV3Mean = mean(stepV3, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(new demo)\DPB_r_0.6_alpha_100.0_trial_',num2str(i),'.txt']);
%     s = ['stepV4(:,count) = DPB_r_0_6_alpha_100_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV4Mean = mean(stepV4, 2);
% 
% x = 1:1:50;
% plot(x,stepV1Mean(1:50),'r');
% hold on;
% plot(x,stepV2Mean(1:50),'g');
% hold on;
% plot(x,stepV3Mean(1:50),'b');
% hold on;
% plot(x,stepV4Mean(1:50),'k');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPB(para)\DPB_r_0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepV1(:,count) = DPB_r_0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV1Mean = mean(stepV1, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPB(para)\DPB_r_0.7_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepV2(:,count) = DPB_r_0_7_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV2Mean = mean(stepV2, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPB(para)\DPB_r_0.8_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepV3(:,count) = DPB_r_0_8_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepV3Mean = mean(stepV3, 2);
% 
% x = 1:1:50;
% plot(x,stepV1Mean(1:50),'r');
% hold on;
% plot(x,stepV2Mean(1:50),'g');
% hold on;
% plot(x,stepV3Mean(1:50),'b');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo2_trial',num2str(i),'.txt']);
    s = ['stepDPBV21(:,count) = DPB_demo2_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV21Mean = mean(stepDPBV21, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo4_trial',num2str(i),'.txt']);
    s = ['stepDPBV22(:,count) = DPB_demo4_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV22Mean = mean(stepDPBV22, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo6_trial',num2str(i),'.txt']);
    s = ['stepDPBV23(:,count) = DPB_demo6_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV23Mean = mean(stepDPBV23, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo8_trial',num2str(i),'.txt']);
    s = ['stepDPBV24(:,count) = DPB_demo8_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV24Mean = mean(stepDPBV24, 2);

count = 1;
for i = 0:99
    load(['results\acrobot\DPB(v2)\DPB_demo10_trial',num2str(i),'.txt']);
    s = ['stepDPBV25(:,count) = DPB_demo10_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV25Mean = mean(stepDPBV25, 2);

x = 1:1:50;
semilogx(x,stepDPBV21Mean,'r');
hold on;
plot(x,stepDPBV22Mean,'g');
hold on;
plot(x,stepDPBV23Mean,'b');
hold on;
plot(x,stepDPBV24Mean,'k');
hold on;
plot(x,stepDPBV25Mean,'y');

legend('2','4','6','8','10');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v111)\PB_demo2_trial',num2str(i),'.txt']);
    s = ['stepDPBV11(:,count) = PB_demo2_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV11Mean = mean(stepDPBV11, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v111)\PB_demo4_trial',num2str(i),'.txt']);
    s = ['stepDPBV12(:,count) = PB_demo4_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV12Mean = mean(stepDPBV12, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v111)\PB_demo6_trial',num2str(i),'.txt']);
    s = ['stepDPBV13(:,count) = PB_demo6_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV13Mean = mean(stepDPBV13, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v111)\PB_demo8_trial',num2str(i),'.txt']);
    s = ['stepDPBV14(:,count) = PB_demo8_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV14Mean = mean(stepDPBV14, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v111)\PB_demo10_trial',num2str(i),'.txt']);
    s = ['stepDPBV15(:,count) = PB_demo10_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV15Mean = mean(stepDPBV15, 2);

x = 1:1:50;
plot(x,stepDPBV11Mean,'r');
hold on;
plot(x,stepDPBV12Mean,'g');
hold on;
plot(x,stepDPBV13Mean,'b');
hold on;
plot(x,stepDPBV14Mean,'k');
hold on;
plot(x,stepDPBV15Mean,'y');

legend('2','4','6','8','10');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v311)\DPB_demo2_trial',num2str(i),'.txt']);
    s = ['stepDPBV31(:,count) = DPB_demo2_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV31Mean = mean(stepDPBV31, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v311)\DPB_demo4_trial',num2str(i),'.txt']);
    s = ['stepDPBV32(:,count) = DPB_demo4_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV32Mean = mean(stepDPBV32, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v311)\DPB_demo6_trial',num2str(i),'.txt']);
    s = ['stepDPBV33(:,count) = DPB_demo6_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV33Mean = mean(stepDPBV33, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v311)\DPB_demo8_trial',num2str(i),'.txt']);
    s = ['stepDPBV34(:,count) = DPB_demo8_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV34Mean = mean(stepDPBV34, 2);

count = 1;
for i = 0:499
    load(['results\acrobot\DPB(v311)\DPB_demo10_trial',num2str(i),'.txt']);
    s = ['stepDPBV35(:,count) = DPB_demo10_trial',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDPBV35Mean = mean(stepDPBV35, 2);

x = 1:1:50;
plot(x,stepDPBV31Mean,'r');
hold on;
plot(x,stepDPBV32Mean,'g');
hold on;
plot(x,stepDPBV33Mean,'b');
hold on;
plot(x,stepDPBV34Mean,'k');
hold on;
plot(x,stepDPBV35Mean,'y');

legend('2','4','6','8','10');
% count = 1;
% for i = 0:99
%     load(['results\acrobot\PB\PB_trial_',num2str(i),'.txt']);
%     s = ['step(:,count) = PB_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepMean = mean(step, 2);

% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew\DPB_r_0.6_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepD(:,count) = DPB_r_0_6_alpha_10_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDMean = mean(stepD, 2);
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPB(v1)\PB_trial_',num2str(i),'.txt']);
%     s = ['stepD(:,count) = PB_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDMean = mean(stepD, 2);
% 
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(new demo)\DPB_r_0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDD(:,count) = DPB_r_0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDMean = mean(stepDD, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPB(v3)\DPB_r_0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r_0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);


% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew(only demo)\DPB_r_0.6_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r_0_6_alpha_10_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);



% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew\DPB_r_0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDD(:,count) = DPB_r_0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDMean = mean(stepDD, 2);
% 
% count = 1;
% for i = 0:99
%     load(['results\acrobot\DPBNew\DPB_r_0.6_alpha_100.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r_0_6_alpha_100_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);

% 

% x = 1:1:50;
% plot(x,stepMean(1:50),'r');
% hold on;
% plot(x,stepDDMean(1:50),'g');
% hold on;
% plot(x,stepDMean(1:50),'b');
% hold on;
% plot(x,stepDDDMean(1:50),'k');

%legend('PB','C = 0.1','C = 1', 'C = 10');
xlabel('Iteration','FontName','Times New Roman','FontSize',20)
ylabel('Num of steps','FontName','Times New Roman','FontSize',20)
%plot(x(1:10:100),stepMean(1:10:100),'o', 'MarkerFaceColor','b', 'MarkerEdgeColor','b');

%%%%%%%%%%%%
%1.r=0.6,alpha=10 good
    