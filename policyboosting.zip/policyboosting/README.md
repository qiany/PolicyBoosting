policyboosting
==============

A Java Reinforcement Learning Toolkit for Policy Boosting

