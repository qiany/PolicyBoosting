clear;
count = 1;
for i = 0:5
    load(['results\helicopter\PB\PBWP_trial_',num2str(i),'.txt']);
    s = ['step(:,count) = PBWP_trial_',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepMean = mean(step, 2);

count = 1;
for i = 0:8
    load(['results\helicopter\DPB\DPB_r_1000000.0_alpha_1.0_trial_',num2str(i),'.txt']);
    s = ['stepD(:,count) = DPB_r_1000000_0_alpha_1_0_trial_',num2str(i),'(:,4)'];
    eval(s);
    count = count + 1;
end
stepDMean = mean(stepD, 2);



% count = 1;
% for i = 0:65
%     load(['results\pac\DPB(old demo)\DPB_r_0.8_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepD(:,count) = DPB_r_0_8_alpha_10_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDMean = mean(stepD, 2);
% 
% count = 1;
% for i = 0:65
%     load(['results\pac\DPB(new reward)\DPB_r_0.8_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepDD(:,count) = DPB_r_0_8_alpha_10_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDMean = mean(stepDD, 2);


% count = 1;
% for i = 0:65
%     load(['results\pac\DPB(old demo)\DPB_r_0.8_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r_0_8_alpha_10_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);



% count = 1;
% for i = 0:99
%     load(['results\mc\DPBNew(new demo)\DPB_r0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r0_6_alpha_1_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);


% count = 1;
% for i = 0:79
%     load(['results\mc\DPBNew\DPB_r0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDD(:,count) = DPB_r0_6_alpha_1_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDMean = mean(stepDD, 2);
% % 
% count = 1;
% for i = 0:79
%     load(['results\mc\DPBNew\DPB_r0.6_alpha_100.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r0_6_alpha_100_0_trial_',num2str(i),'(:,3)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);


x = 1:1:1000;
plot(x,stepMean, 'r');
hold on;
plot(x,stepDMean,'b');
hold on;
% plot(x,stepDDMean,'g');
% hold on;
% plot(x,stepDDDMean,'k');
% legend('PB','NPPG','PB+Demo','Demo');
% legend('PB','C = 0.1','C = 1', 'C = 10');
xlabel('Iteration','FontName','Times New Roman','FontSize',20)
ylabel('Scores','FontName','Times New Roman','FontSize',20)
%plot(x(1:10:100),stepMean(1:10:100),'o', 'MarkerFaceColor','b', 'MarkerEdgeColor','b');



