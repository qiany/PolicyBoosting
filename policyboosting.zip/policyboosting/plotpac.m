clear;
count = 1;
for i = 0:99
    load(['results\pac\NPPG\trial_',num2str(i),'.txt']);
    s = ['stepNPPG(:,count) = trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepNPPGMean = mean(stepNPPG, 2);

count = 1;
for i = 0:99
    load(['results\pac\PB(new reward)\trial_',num2str(i),'.txt']);
    s = ['stepPB(:,count) = trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepPBMean = mean(stepPB, 2);

count = 1;
for i = 0:74
    load(['results\pac\DPB(v11)\PB_demo_10_trial_',num2str(i),'.txt']);
    s = ['stepDPBV1(:,count) = PB_demo_10_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV1Mean = mean(stepDPBV1, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(new reward)\DPB_r_0.8_alpha_10.0_trial_',num2str(i),'.txt']);
    s = ['stepDPBV2(:,count) = DPB_r_0_8_alpha_10_0_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV2Mean = mean(stepDPBV2, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo10_trial_',num2str(i),'.txt']);
    s = ['stepDPBV3(:,count) = DPB_demo10_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end

stepDPBV3Mean = mean(stepDPBV3, 2);


x = 1:1:50;

plot(x,stepNPPGMean(1:50) * 1000,'g');
hold on;
plot(x,stepPBMean(1:50) * 1000,'r');
hold on;
plot(x,stepDPBV1Mean(1:50) * 1000,'b');
hold on;
plot(x,stepDPBV2Mean(1:50) * 1000,'k');
hold on;
plot(x,stepDPBV3Mean(1:50) * 1000,'y');

legend('PB','NPPG', 'DPBV1','DPBV2','DPBV3');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:99
    load(['results\pac\DPB(v21)\DPB_demo2_trial_',num2str(i),'.txt']);
    s = ['stepDPBV21(:,count) = DPB_demo2_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV21Mean = mean(stepDPBV21, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v21)\DPB_demo4_trial_',num2str(i),'.txt']);
    s = ['stepDPBV22(:,count) = DPB_demo4_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV22Mean = mean(stepDPBV22, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v21)\DPB_demo6_trial_',num2str(i),'.txt']);
    s = ['stepDPBV23(:,count) = DPB_demo6_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV23Mean = mean(stepDPBV23, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v21)\DPB_demo8_trial_',num2str(i),'.txt']);
    s = ['stepDPBV24(:,count) = DPB_demo8_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV24Mean = mean(stepDPBV24, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v21)\DPB_demo10_trial_',num2str(i),'.txt']);
    s = ['stepDPBV25(:,count) = DPB_demo10_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV25Mean = mean(stepDPBV25, 2);

x = 1:1:50;
plot(x,stepDPBV21Mean(1:50) * 1000,'r');
hold on;
plot(x,stepDPBV22Mean(1:50) * 1000,'g');
hold on;
plot(x,stepDPBV23Mean(1:50) * 1000,'b');
hold on;
plot(x,stepDPBV24Mean(1:50) * 1000,'k');
hold on;
plot(x,stepDPBV25Mean(1:50) * 1000,'y');

legend('2','4','6','8','10');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:99
    load(['results\pac\DPB(v11)\PB_demo_2_trial_',num2str(i),'.txt']);
    s = ['stepDPBV11(:,count) = PB_demo_2_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV11Mean = mean(stepDPBV11, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v11)\PB_demo_4_trial_',num2str(i),'.txt']);
    s = ['stepDPBV12(:,count) = PB_demo_4_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV12Mean = mean(stepDPBV12, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v11)\PB_demo_6_trial_',num2str(i),'.txt']);
    s = ['stepDPBV13(:,count) = PB_demo_6_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV13Mean = mean(stepDPBV13, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v11)\PB_demo_8_trial_',num2str(i),'.txt']);
    s = ['stepDPBV14(:,count) = PB_demo_8_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV14Mean = mean(stepDPBV14, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v11)\PB_demo_10_trial_',num2str(i),'.txt']);
    s = ['stepDPBV15(:,count) = PB_demo_10_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV15Mean = mean(stepDPBV15, 2);

x = 1:1:50;
plot(x,stepDPBV11Mean(1:50) * 1000,'r');
hold on;
plot(x,stepDPBV12Mean(1:50) * 1000,'g');
hold on;
plot(x,stepDPBV13Mean(1:50) * 1000,'b');
hold on;
plot(x,stepDPBV14Mean(1:50) * 1000,'k');
hold on;
plot(x,stepDPBV15Mean(1:50) * 1000,'y');

legend('2','4','6','8','10');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo2_trial_',num2str(i),'.txt']);
    s = ['stepDPBV31(:,count) = DPB_demo2_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV31Mean = mean(stepDPBV31, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo4_trial_',num2str(i),'.txt']);
    s = ['stepDPBV32(:,count) = DPB_demo4_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV32Mean = mean(stepDPBV32, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo6_trial_',num2str(i),'.txt']);
    s = ['stepDPBV33(:,count) = DPB_demo6_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV33Mean = mean(stepDPBV33, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo8_trial_',num2str(i),'.txt']);
    s = ['stepDPBV34(:,count) = DPB_demo8_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV34Mean = mean(stepDPBV34, 2);

count = 1;
for i = 0:99
    load(['results\pac\DPB(v31)\DPB_demo10_trial_',num2str(i),'.txt']);
    s = ['stepDPBV35(:,count) = DPB_demo10_trial_',num2str(i),'(:,2)'];
    eval(s);
    count = count + 1;
end
stepDPBV35Mean = mean(stepDPBV35, 2);

x = 1:1:50;
plot(x,stepDPBV31Mean(1:50) * 1000 ,'r');
hold on;
plot(x,stepDPBV32Mean(1:50) * 1000,'g');
hold on;
plot(x,stepDPBV33Mean(1:50) * 1000,'b');
hold on;
plot(x,stepDPBV34Mean(1:50) * 1000,'k');
hold on;
plot(x,stepDPBV35Mean(1:50) * 1000,'y');

legend('2','4','6','8','10');



% count = 1;
% for i = 0:79
%     load(['results\mc\DPB\DPB_r0.6_trial_',num2str(i),'.txt']);
%     s = ['stepD(:,count) = DPB_r0_6_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDMean = mean(stepD, 2);





% count = 1;
% for i = 0:65
%     load(['results\pac\DPB(old demo)\DPB_r_0.8_alpha_10.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r_0_8_alpha_10_0_trial_',num2str(i),'(:,2)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);



% count = 1;
% for i = 0:99
%     load(['results\mc\DPBNew(new demo)\DPB_r0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);


% count = 1;
% for i = 0:79
%     load(['results\mc\DPBNew\DPB_r0.6_alpha_1.0_trial_',num2str(i),'.txt']);
%     s = ['stepDD(:,count) = DPB_r0_6_alpha_1_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDMean = mean(stepDD, 2);
% % 
% count = 1;
% for i = 0:79
%     load(['results\mc\DPBNew\DPB_r0.6_alpha_100.0_trial_',num2str(i),'.txt']);
%     s = ['stepDDD(:,count) = DPB_r0_6_alpha_100_0_trial_',num2str(i),'(:,4)'];
%     eval(s);
%     count = count + 1;
% end
% stepDDDMean = mean(stepDDD, 2);



% plot(x,stepDDDMean,'k');
% legend('PB','NPPG','PB+Demo','Demo');
% legend('PB','C = 0.1','C = 1', 'C = 10');
xlabel('Iteration','FontName','Times New Roman','FontSize',20)
ylabel('Scores','FontName','Times New Roman','FontSize',20)
%plot(x(1:10:100),stepMean(1:10:100),'o', 'MarkerFaceColor','b', 'MarkerEdgeColor','b');



%%%%%
%1. c = 1; c = 10; almost same; insensitive to c
